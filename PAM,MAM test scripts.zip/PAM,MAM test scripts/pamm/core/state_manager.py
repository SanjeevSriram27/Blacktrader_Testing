"""
State Manager for PAMM Accounts, Pools, and Trade Orders
Persists local state to JSON to power the Unified Dashboard and Test Runner.
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from core.config import Config

class StateManager:
    def __init__(
        self,
        accounts_file=Config.ACCOUNTS_FILE,
        pools_file=Config.POOLS_FILE,
        orders_file=Config.ORDERS_FILE,
    ):
        self.accounts_file = Path(accounts_file)
        self.pools_file = Path(pools_file)
        self.orders_file = Path(orders_file)
        self._ensure_files()

    def _ensure_files(self):
        self.accounts_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.accounts_file.exists():
            self._save_json(self.accounts_file, self._default_accounts())
        if not self.pools_file.exists():
            self._save_json(self.pools_file, self._default_pools())
        if not self.orders_file.exists():
            self._save_json(self.orders_file, self._default_orders())

    def _save_json(self, path: Path, data: Any):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _load_json(self, path: Path) -> Any:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _default_accounts(self) -> List[Dict[str, Any]]:
        # Seed 10 realistic test follower accounts
        accounts = []
        for i in range(1, 11):
            deposit = 500.0 + (i * 250.0)
            accounts.append({
                "index": i,
                "email": f"pamfollower{i}@mailinator.com",
                "name": f"PAMM Follower #{i}",
                "deposit": deposit,
                "wallet_balance": 10000.0 - deposit,
                "status": "FOLLOWING" if i <= 7 else "ACTIVE",
                "pool_id": "pmm_e6c12d2fd2ea8c6ac0" if i <= 7 else None,
                "hwm": deposit,
                "current_equity": deposit + (12.50 * (i % 3)),
                "running_pnl": 12.50 * (i % 3),
                "created_at": "2026-11-16 12:00:00"
            })
        return accounts

    def _default_pools(self) -> List[Dict[str, Any]]:
        return [
            {
                "pool_id": "pmm_hedging_alpha",
                "master_client_id": "mem_master_hedging",
                "display_name": Config.HEDGING_POOL_NAME,
                "manager_email": Config.HEDGING_MASTER_EMAIL,
                "share_percent": Config.HEDGING_MANAGER_SHARE_PERCENT,
                "instance": "real",
                "total_equity": 177175.00,
                "total_units": 1771.75,
                "nav_per_unit": 100.00,
                "status": "ACTIVE",
                "followers_count": 10,
                "open_positions_count": 0,
                "created_at": "2026-11-16 10:30:00"
            },
            {
                "pool_id": "pmm_netting_alpha",
                "master_client_id": "mem_master_netting",
                "display_name": Config.NETTING_POOL_NAME,
                "manager_email": Config.NETTING_MASTER_EMAIL,
                "share_percent": Config.NETTING_MANAGER_SHARE_PERCENT,
                "instance": "real-net",
                "total_equity": 100000.00,
                "total_units": 1000.00,
                "nav_per_unit": 100.00,
                "status": "ACTIVE",
                "followers_count": 5,
                "open_positions_count": 0,
                "created_at": "2026-11-16 11:00:00"
            }
        ]

    def _default_orders(self) -> List[Dict[str, Any]]:
        return [
            {
                "order_id": "ord_9821a",
                "symbol": "EURUSD",
                "side": "BUY",
                "qty": 2.0,
                "fill_price": 1.08250,
                "exit_price": 1.08310,
                "realized_pnl": 12.00,
                "status": "CLOSED",
                "pool_id": "pmm_e6c12d2fd2ea8c6ac0",
                "timestamp": "2026-11-16 13:15:20"
            }
        ]

    # Accounts API
    def get_accounts(self) -> List[Dict[str, Any]]:
        return self._load_json(self.accounts_file)

    def add_account(self, email: str, deposit: float = 1000.0, status: str = "ACTIVE") -> Dict[str, Any]:
        accounts = self.get_accounts()
        idx = len(accounts) + 1
        account = {
            "index": idx,
            "email": email,
            "name": f"PAMM Follower #{idx}",
            "deposit": deposit,
            "wallet_balance": 10000.0 - deposit,
            "status": status,
            "pool_id": None,
            "hwm": deposit,
            "current_equity": deposit,
            "running_pnl": 0.0,
            "created_at": "2026-11-16 14:00:00"
        }
        accounts.append(account)
        self._save_json(self.accounts_file, accounts)
        return account

    def update_account(self, email: str, updates: Dict[str, Any]):
        accounts = self.get_accounts()
        for a in accounts:
            if a["email"] == email:
                a.update(updates)
                break
        self._save_json(self.accounts_file, accounts)

    # Pools API
    def get_pools(self) -> List[Dict[str, Any]]:
        return self._load_json(self.pools_file)

    def update_pool(self, pool_id: str, updates: Dict[str, Any]):
        pools = self.get_pools()
        for p in pools:
            if p["pool_id"] == pool_id:
                p.update(updates)
                break
        self._save_json(self.pools_file, pools)

    # Orders API
    def get_orders(self) -> List[Dict[str, Any]]:
        return self._load_json(self.orders_file)

    def add_order(self, order_dict: Dict[str, Any]):
        orders = self.get_orders()
        orders.insert(0, order_dict)
        self._save_json(self.orders_file, orders)

